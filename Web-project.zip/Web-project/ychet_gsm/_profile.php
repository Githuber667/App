<?php
$user = (new UserMap())->findProfileById($id);
if ($user) {
?>
<tr>
    <th>Ф.И.О.</th>
    <td><?=$user->fio;?></td>
</tr>
<tr>
    <th>Логин</th>
    <td><?=$user->login;?></td>
</tr>
<tr>
    <th>Роль</th>
    <td><?=$user->role;?></td>
</tr>
<?php } ?>