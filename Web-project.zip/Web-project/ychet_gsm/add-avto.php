<?php
require_once 'secure.php';
if (!Helper::can('admin') && !Helper::can('manager')) {
    header('Location: 404.php');
    exit();
    }
$id = 0;
if (isset($_GET['id'])) {
    $id = Helper::clearInt($_GET['id']);
}
$avto = (new AvtoMap())->findById($id);
$header = (($id)?'Редактировать':'Добавить').' автомобиль';
require_once 'template/header.php';
?>
<section class="content-header">
    <h1><?=$header;?></h1>
    <ol class="breadcrumb">

        <li><a href="/index.php"><i class="fa fa-dashboard"></i> Главная</a></li>

        <li><a href="list-avto.php">Автомобили</a></li>
        <li class="active"><?=$header;?></li>
    </ol>
</section>
<div class="box-body">
<form action="save-avto.php" method="POST">
        <div class="form-group">
            <label>Марка</label>
            <input type="text" class="form-control" name="marka" required="required" value="<?=$avto->marka;?>">
    </div>

    <div class="form-group">
            <label> Гос номер</label>
            <input type="text" class="form-control" name="gos_num" required="required" value="<?=$avto->gos_num;?>">
    </div>

    

    <div class="form-group">
        <button type="submit" name="saveAvto" class="btn btn-primary">Сохранить</button>
    </div>
    <input type="hidden" name="id_avto" value="<?=$id;?>"/>
</form>
</div>
<?php
require_once 'template/footer.php';
?> 