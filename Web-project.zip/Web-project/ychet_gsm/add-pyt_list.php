<?php
    require_once 'secure.php';
    if (!Helper::can('admin') && !Helper::can('manager')) {
        header('Location: 404.php');
        exit();
        }
    $id = 0;
    if (isset($_GET['id'])) {
        $id = Helper::clearInt($_GET['id']);
    }
    $pyt_list = (new Pyt_listMap())->findById($id);
    $header = (($id)?'Редактировать данные':'Добавить').' путевой лист';
    require_once 'template/header.php';
?>
<section class="content-header">
    <h1><?=$header;?></h1>
    <ol class="breadcrumb">
    <li><a href="/index.php"><i class="fa fa-dashboard"></i> Главная</a></li>
    <li><a href="list-pyt_list.php">Путевые листы</a></li>
    <li class="active"><?=$header;?></li>
    </ol>
</section>
<div class="box-body">
<form action="save-pyt_list.php" method="POST">
    <div class="form-group">
        <label>Водитель</label>
        <select class="form-control" name="id_voditel">
        <?= Helper::printSelectOptions($pyt_list->id_voditel, (new VoditelMap())->arrVoditels());?>
        </select>
    </div> 
    
    <div class="form-group">
        <label>Автомобили</label>
        <select class="form-control" name="id_avto">
            <?= Helper::printSelectOptions($pyt_list->id_avto, (new AvtoMap())->arrAvtos());?>
        </select>
    </div>

    <div class="form-group">
            <label>Место</label>
            <input type="text" class="form-control" name="point" required="required" value="<?=$pyt_list->point;?>">
    </div>

    <div class="form-group">
        <button type="submit" name="savePyt_list" class="btn btn-primary">Сохранить</button>
    </div>
    <input type="hidden" name="id_pyt_list" value="<?=$id;?>"/>

</form>
</div>
<?php
require_once 'template/footer.php';
?>
