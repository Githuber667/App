<?php


class AvtoMap extends BaseMap
{

    public function arrAvtos(){
        $res = $this->db->query("SELECT id_avto AS id, marka AS value FROM avto"); 
        return $res->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_avto, marka, gos_num". "FROM avto WHERE id_avto = $id");
            return $res->fetchObject("Avto");
        }
        return new Avto();
    }
    
    public function save(Avto $avto){
       // print_r($avto);//////////////////////////////////////////////
        if ($avto->validate()) {
            if ($avto->id_avto == 0) {
                return $this->insert($avto);
            } 
            else {
                return $this->update($avto);
            }
        }
        return false;
    }

    private function insert(Avto $avto){///////////////////////////////////////////////////////////////////////////////////////////////////////
        $marka = $this->db->quote($avto->marka);
        $gos_num = $this->db->quote($avto->gos_num);
        if ($this->db->exec("INSERT INTO avto(marka, gos_num)"." VALUES($marka, $gos_num)") == 1) {
            $avto->id_avto = $this->db->lastInsertId();
            return true;
        }
        return false;
    }

    private function update(Avto $avto){
        $marka = $this->db->quote($avto->marka);
        if ( $this->db->exec("UPDATE avto SET marka = $marka,"." gos_num= $avto->gos_num WHERE id_avto = ".$avto->id_avto) == 1) {
            return true;
        }
        return false;
    }

    public function findAll($ofset=0, $limit=30){
        $res = $this->db->query("SELECT id_avto, marka, gos_num"." FROM avto LIMIT $ofset,$limit");
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function count(){
        $res = $this->db->query("SELECT COUNT(*) AS cnt FROM avto");
        return $res->fetch(PDO::FETCH_OBJ)->cnt;
    }

    public function findViewById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_avto, marka, gos_num "."FROM avto WHERE id_avto =$id");
            return $res->fetch(PDO::FETCH_OBJ);
        }
    return false;
    }
}