<?php

abstract class Config
{
    const HOST = 'localhost';
    const DB_NAME = 'ychet_gsm';
    const DB_USER = 'root';
    const DB_PASSWORD = '';
}