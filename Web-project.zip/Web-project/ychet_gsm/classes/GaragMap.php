<?php


class GaragMap extends BaseMap
{
    public function arrGarags(){
        $res = $this->db->query("SELECT id_garag AS id, name AS value FROM garag");
        return $res->fetchAll(PDO::FETCH_ASSOC);
    }
}