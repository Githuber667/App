<?php


class GsmMap extends BaseMap
{
    public function arrGsms(){
        $res = $this->db->query("SELECT id_gsm AS id, name AS value FROM gsm");
        return $res->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_gsm, name, active". "FROM gsm WHERE id_gsm = $id");
            return $res->fetchObject("Gsm");
        }
        return new Gsm();
    }
    
    public function save(Gsm $gsm){
        if ($gsm->validate()) {
            if ($gsm->id_gsm == 0) {
                return $this->insert($gsm);
            } 
            else {
                return $this->update($gsm);
            }
        }
        return false;
    }

    private function insert(Gsm $gsm){///////////////////////////////////////////////////////////////////////////////////////////////////////
        $name = $this->db->quote($gsm->name);
        if ($this->db->exec("INSERT INTO gsm(name)". " VALUES($name)") == 1) {
            $gsm->id_gsm = $this->db->lastInsertId();
            return true;
        }
        return false;
    }

    private function update(Gsm $gsm){
        $name = $this->db->quote($gsm->name);
        if ( $this->db->exec("UPDATE gsm SET name = $name ". " WHERE id_gsm = ".$gsm->id_gsm) == 1) {
            return true;
        }
        return false;
    }

    public function findAll($ofset=0, $limit=30){
        $res = $this->db->query("SELECT id_gsm, name". " FROM gsm LIMIT $ofset,$limit");
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function count(){
        $res = $this->db->query("SELECT COUNT(*) AS cnt FROM gsm");
        return $res->fetch(PDO::FETCH_OBJ)->cnt;
    }

    public function findViewById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_gsm, name ". " FROM gsm WHERE id_gsm =$id");
            return $res->fetch(PDO::FETCH_OBJ);
        }
    return false;
    }

}