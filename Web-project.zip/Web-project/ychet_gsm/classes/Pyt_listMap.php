<?php


class Pyt_listMap extends BaseMap
{

    public function findById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_pyt_list, id_voditel, id_avto, point ". "FROM pyt_list WHERE id_pyt_list = $id");
            return $res->fetchObject("Pyt_list");
        }
        return new Pyt_list();
    }
    
    public function save(Pyt_list $pyt_list){
           //  print_r($pyt_list); 
        if ($pyt_list->validate()) {
            if ($pyt_list->id_pyt_list == 0) {
                return $this->insert($pyt_list);
            } 
            else {
                return $this->update($pyt_list);
            }
        }
        return false;
    }

    private function insert(Pyt_list $pyt_list){///////////////////////////////////////////////////////////////////////////////////////////////////////
        $point = $this->db->quote($pyt_list->point);
        if ($this->db->exec("INSERT INTO pyt_list(point)". " VALUES($point)") == 1) {
            $pyt_list->id_pyt_list = $this->db->lastInsertId();
            return true;
        }
        return false;
    }

    private function update(Pyt_list $pyt_list){
        $point = $this->db->quote($pyt_list->point);
        if ( $this->db->exec("UPDATE pyt_list SET point = $point ". " WHERE id_pyt_list = ".$pyt_list->id_pyt_list) == 1) {
            return true;
        }
        return false;
    }

    public function findAll($ofset=0, $limit=30){
        $res = $this->db->query("SELECT id_pyt_list, id_voditel, id_avto, point". " FROM pyt_list LIMIT $ofset,$limit");
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function count(){
        $res = $this->db->query("SELECT COUNT(*) AS cnt FROM pyt_list");
        return $res->fetch(PDO::FETCH_OBJ)->cnt;
    }

    public function findViewById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_pyt_list, id_voditel, id_avto, point ". " FROM pyt_list WHERE id_pyt_list =$id");
            return $res->fetch(PDO::FETCH_OBJ);
        }
    return false;
    }

}