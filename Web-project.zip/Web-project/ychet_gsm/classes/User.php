<?php


class User extends Table
{
    public $id_user=0;
    public $lastname='';
    public $firstname='';
    public $patronymic='';
    public $login='';
    public $pass='';
    public $role_id=0;
    public function validate()
    {
        if (!empty($this->lastname) &&
        !empty($this->firstname) &&
        !empty($this->login) &&
        !empty($this->pass) &&
        !empty($this->role_id)) {
        return true;
    }
    return false;
    }
}