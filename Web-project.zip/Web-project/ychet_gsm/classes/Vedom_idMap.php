<?php


class Vedom_idMap extends BaseMap
{

}