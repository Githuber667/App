<?php


class VedomostMap extends BaseMap
{

}