<?php


class VoditelMap extends BaseMap
{
    public function arrVoditels(){
        $res = $this->db->query("SELECT user.id_user AS id, CONCAT(user.firstname,' ', user.lastname,' ', user.patronymic) AS value  FROM voditel INNER JOIN user ON voditel.id_user=user.id_user");
        return $res->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_user, id_garag
            FROM voditel WHERE id_user = $id");
            $voditel = $res->fetchObject("Voditel");
            if ($voditel) {
            return $voditel;
            }
        }
        return new Voditel();
    }

    public function save(User $user, Voditel $voditel){
        if ($user->validate() && $voditel->validate() && (new UserMap())->save($user)) {
            if ($voditel->id_user == 0) {
                $voditel->id_user = $user->id_user;
                return $this->insert($voditel);
            } 
            else {
                 return $this->update($voditel);
            }
        }
        return false;
    }

    private function insert(Voditel $voditel){
        if ($this->db->exec("INSERT INTO voditel(id_user, id_garag) VALUES($voditel->id_user, $voditel->id_garag)") == 1) {
            return true;
        }
    return false;
    }

    private function update(Voditel $voditel){
        if ($this->db->exec("UPDATE voditel SET id_garag = $voditel->id_garag WHERE id_user=".$voditel->id_user) == 1) {
            return true;
        }
    return false;
    }

    public function findAll($ofset=0, $limit=30){
        $res = $this->db->query("SELECT user.id_user, CONCAT(user.lastname,' ', user.firstname, ' ', user.patronymic) AS fio, ". " garag.name AS garag, role.name AS role FROM user INNER JOIN voditel ON user.id_user=voditel.id_user ". "INNER JOIN garag ON voditel.id_garag=garag.id_garag" . " INNER JOIN role ON user.role_id=role.role_id LIMIT $ofset, $limit");
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function count(){
        $res = $this->db->query("SELECT COUNT(*) AS cnt FROM voditel");
        return $res->fetch(PDO::FETCH_OBJ)->cnt; 
    }
    public function findProfileById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT voditel.id_user, garag.name AS garag FROM voditel ". "INNER JOIN garag ON voditel.id_garag=garag.id_garag WHERE voditel.id_user =$id");
            return $res->fetch(PDO::FETCH_OBJ);
        }
        return false; 
    }
}