<?php


class ZapravshikMap extends BaseMap
{
    public function findById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT id_user, id_garag
            FROM zapravshik WHERE id_user = $id");
            $zapravshik = $res->fetchObject("Zapravshik");
            if ($zapravshik) {
            return $zapravshik;
            }
        }
        return new Zapravshik();
    }

    public function save(User $user,Zapravshik $zapravshik){
        if ($user->validate() && $zapravshik->validate() && (new UserMap())->save($user)) {
            if ($zapravshik->id_user == 0) {
                $zapravshik->id_user = $user->id_user;
                return $this->insert($zapravshik);
            } 
            else {
                 return $this->update($zapravshik);
            }
        }
        return false;
    }

    private function insert(Zapravshik $zapravshik){
        if ($this->db->exec("INSERT INTO zapravshik(id_user, id_garag) VALUES($zapravshik->id_user, $zapravshik->id_garag)") == 1) {
            return true;
        }
    return false;
    }

    private function update(Zapravshik $zapravshik){
        if ($this->db->exec("UPDATE zapravshik SET id_garag = $zapravshik->id_garag WHERE id_user=".$zapravshik->id_user) == 1) {
            return true;
        }
    return false;
    }

    public function findAll($ofset=0, $limit=30){
        $res = $this->db->query("SELECT user.id_user, CONCAT(user.lastname,' ', user.firstname, ' ', user.patronymic) AS fio, ". " garag.name AS garag, role.name AS role FROM user INNER JOIN zapravshik ON user.id_user=zapravshik.id_user ". "INNER JOIN garag ON zapravshik.id_garag=garag.id_garag" . " INNER JOIN role ON user.role_id=role.role_id LIMIT $ofset, $limit");
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function count(){
        $res = $this->db->query("SELECT COUNT(*) AS cnt FROM zapravshik");
        return $res->fetch(PDO::FETCH_OBJ)->cnt; 
    }

    public function findProfileById($id=null){
        if ($id) {
            $res = $this->db->query("SELECT zapravshik.id_user, garag.name AS garag FROM zapravshik ". "INNER JOIN garag ON zapravshik.id_garag=garag.id_garag WHERE zapravshik.id_user =$id");
            return $res->fetch(PDO::FETCH_OBJ);
        }
        return false; 
    }

}