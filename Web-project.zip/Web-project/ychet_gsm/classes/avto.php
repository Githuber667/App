<?php


class avto extends Table
{
    public $id_avto=0;
    public $marka='';
    public $gos_num='';

    public function validate()
    {
        if (!empty($this->marka) &&
            !empty($this->gos_num)) {
            return true;
        }
       
        return false;
    }
}