<?php


class garag extends Table
{
    public $id_garag=0;
    public $name='';
    public function validate()
    {
        return false;
    }

}