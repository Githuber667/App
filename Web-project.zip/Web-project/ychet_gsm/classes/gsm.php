<?php


class gsm extends Table
{
    public $id_gsm=0;
    public $name='';

    public function validate()
    {
        if (!empty($this->name)) {
        return true;
    }
    return false;
    }
}
