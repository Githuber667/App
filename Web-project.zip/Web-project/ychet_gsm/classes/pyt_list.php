<?php


class pyt_list extends Table
{
    public $id_pyt_list=0;
    public $id_voditel=0;
    public $id_avto=0;
    public $point='';

    public function validate()
    {
        if (!empty($this->id_voditel) &&
            !empty($this->id_avto) &&
            !empty($this->point)) {
            return true;
        }
        return false;
    }
}