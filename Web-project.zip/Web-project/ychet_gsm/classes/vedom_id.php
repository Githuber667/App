<?php


class vedom_id extends Table
{
    public $id_vedomost=0;
    public $id_gsm=0;
    public $kol_vo=0;
    public $id_put_list=0;

    public function validate()
    {
        return false;
    }
}