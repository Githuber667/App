<?php


class vedomost extends Table
{
    public $id_vedomost=0;
    public $id_zapravshik=0;
    public $chislo = '';

    public function validate()
    {
        return false;
    }
}