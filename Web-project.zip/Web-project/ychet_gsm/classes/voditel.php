<?php


class voditel extends Table
{
    public $id_user=0;
    public $id_garag=0;


    public function validate()
    {
        if (!empty($this->id_garag)) {
            return true;
        }
        return false;
    }
}