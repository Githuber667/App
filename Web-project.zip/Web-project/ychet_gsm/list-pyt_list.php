<?php
require_once 'secure.php';
if (!Helper::can('admin') && !Helper::can('manager')) {
    header('Location: 404.php');
    exit();
    }
$size = 5;
if (isset($_GET['page'])) {
    $page = Helper::clearInt($_GET['page']);
} else {
    $page = 1;
}
$pyt_listMap = new Pyt_listMap();
$count = $pyt_listMap->count();
$pyt_lists = $pyt_listMap->findAll($page*$size-$size, $size);
$header = 'Список путевых листов';
require_once 'template/header.php';
?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <section class="content-header">
                <h1><?=$header;?></h1>
                <ol class="breadcrumb">
                <li><a href="/index.php"><i class="fa fa-dashboard"></i> Главная</a></li>
                <li class="active"><?=$header;?></li>
                </ol>
            </section>
            <div class="box-body">

            <a class="btn btn-success" href="add-pyt_list.php">Добавить путевой лист</a>

            </div>
            <div class="box-body">
            <?php
            if ($pyt_lists) {
            ?>
            <table id="example2" class="table table-bordered table-hover">
            <thead>
            <tr>
                <th>Водитель</th>
                <th>Автомобиль</th>
                <th>Адрес</th>
            </tr>
            </thead>    
            <tbody>
            <?php
            foreach ($pyt_lists as $pyt_list) {
            echo '<tr>';
            echo '<td><a href="view-pyt_list.php?id='.$pyt_list->id_pyt_list.'">'.$pyt_list->id_voditel.'</a> '. '<a href="add-pyt_list.php?id='.$pyt_list->id_pyt_list.'"><i class="fa fa-pencil"></i></a></td>';
            echo '<td>'.(($pyt_list->id_avto)).'</td>';
            echo '<td>'.(($pyt_list->point)).'</td>';
            echo '</tr>';
            }
            ?>
            </tbody>
            </table>
            <?php } else {
            echo 'Ни одного путевого листа не найдено';
            } ?>
            </div>
            <div class="box-body">
                <?php Helper::paginator($count, $page,$size); ?>
            </div>
        </div>
    </div>
</div>
<?php
require_once 'template/footer.php';
?>