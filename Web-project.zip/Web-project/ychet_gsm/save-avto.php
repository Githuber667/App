<?php
require_once 'secure.php';
if (!Helper::can('admin') && !Helper::can('manager')) {
    header('Location: 404.php');
    exit();
    }
   //print_r($_POST);
if (isset($_POST['id_avto'])) {
    $avto = new Avto();
    $avto->id_avto = Helper::clearInt($_POST['id_avto']);
    $avto->marka = Helper::clearString($_POST['marka']);
    $avto->gos_num =Helper::clearString($_POST['gos_num']);
    //print_r($avto);
    if ((new AvtoMap())->save($avto)) {
        header('Location: view-avto.php?id='.$avto->id_avto);
    } else {
        if ($avto->id_avto) { 
            header('Location: add-avto.php?id='.$avto->id_avto);
        } else {
            header('Location: add-avto.php');
        }
    }
} 