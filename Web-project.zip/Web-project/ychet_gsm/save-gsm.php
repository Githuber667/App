<?php
require_once 'secure.php';
if (!Helper::can('admin') && !Helper::can('manager')) {
    header('Location: 404.php');
    exit();
    }
if (isset($_POST['id_gsm'])) {
    $gsm = new Gsm();
    $gsm->id_gsm = Helper::clearInt($_POST['id_gsm']);
    $gsm->name = Helper::clearString($_POST['name']);
    if ((new GsmMap())->save($gsm)) {
        header('Location: view-gsm.php?id='.$gsm->id_gsm);
    } else {
        if ($gsm->id_gsm) {
    header('Location: add-gsm.php?id='.$gsm->id_gsm);
        } else {
            header('Location: add-otdel.php');
        }
    }
}