<?php
require_once 'secure.php';
if (!Helper::can('admin') && !Helper::can('manager')) {
    header('Location: 404.php');
    exit();
    }
    //print_r($_POST);
if (isset($_POST['id_pyt_list'])) {
    $pyt_list = new Pyt_list(); 
    $pyt_list->id_pyt_list = Helper::clearInt($_POST['id_pyt_list']);
    $pyt_list->id_voditel = Helper::clearInt($_POST['id_voditel']);
    $pyt_list->id_avto = Helper::clearInt($_POST['id_avto']);
    $pyt_list->point = Helper::clearString($_POST['point']);
    //print_r($pyt_list);
    if ((new Pyt_listMap())->save($pyt_list)) {
        header('Location: view-pyt_list.php?id='.$pyt_list->id_pyt_list);
    } else {
        if ($pyt_list->id_pyt_list) {
    header('Location: add-pyt_list.php?id='.$pyt_list->id_pyt_list);
        } else {
            header('Location: add-pyt_list.php'); 
        }
    }
}