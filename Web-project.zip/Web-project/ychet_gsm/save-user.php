<?php
    require_once 'secure.php';
    if (!Helper::can('admin') && !Helper::can('manager')) {
        header('Location: 404.php');
        exit();
        }
        //print_r($_POST);
    if (isset($_POST['id_user'])) {
        $user = new User();
        $user->id_user= Helper::clearInt($_POST['id_user']);
        $user->lastname = Helper::clearString($_POST['lastname']);
        $user->firstname = Helper::clearString($_POST['firstname']);
        $user->patronymic = Helper::clearString($_POST['patronymic']);
        $user->login = Helper::clearString($_POST['login']);
        $user->pass = password_hash(Helper::clearString($_POST['password']), PASSWORD_BCRYPT);
        $user->role_id = Helper::clearInt($_POST['role_id']);
        $user->active = Helper::clearInt($_POST['active']);
        if (isset($_POST['saveZapravshik'])) {
            $zapravshik = new Zapravshik();
            $zapravshik->id_garag = Helper::clearInt($_POST['id_garag']);
            $zapravshik->id_user = $user->id_user;
            if ((new ZapravshikMap())->save($user, $zapravshik)) {
                header('Location: profile-zapravshik.php?id='.$zapravshik->id_user);
            }  
            else {
                if ($zapravshik->id_user) {
                    header('Location: add-zapravshik.php?id='.$zapravshik->id_user);
                } 
                else {
                    header('Location: add-zapravshik.php');
                }
            }
        exit();
      }
       elseif (isset($_POST['saveVoditel'])) {
            $voditel = new Voditel();
            $voditel->id_user = $user->id_user;
            $voditel->id_garag = Helper::clearInt($_POST['id_garag']);
            if ((new VoditelMap())->save($user, $voditel)) {
                header('Location: profile-voditel.php?id='.$voditel->id_user);
            }  
            else {
                if ($voditel->id_user) {
                    header('Location: add-voditel.php?id='.$voditel->id_user);
                } 
                else {
                    header('Location: add-voditel.php');
                }
            }
        exit();
        }
    }