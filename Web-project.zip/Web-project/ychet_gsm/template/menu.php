<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu" data-widget="tree">
            <li
<?=($_SERVER['PHP_SELF']=='/index.php')?'class="active"':'';?>>
                <a href="index.php"><i class="fa fa-calendar"></i><span>Главная</span></a>
            </li>
            <li class="header">Пользователи</li>
            <li <?=($_SERVER['PHP_SELF']=='/list-zapravshik.php')?'class="active"':'';?>>
                <a href="list-zapravshik.php"><i class="fa fa-users"></i><span>Заправщики</span></a>
            </li>
            <li <?=($_SERVER['PHP_SELF']=='/list-voditel.php')?'class="active"':'';?>>
                <a href="list-voditel.php"><i class="fa fa-users"></i><span>Водители</span></a>
            </li>
            <li class="header">Справочники</li>
            <li <?=($_SERVER['PHP_SELF']=='/list-gsm.php')?'class="active"':'';?>>
                <a href="list-gsm.php"><i class="fa fa-users"></i><span>ГCM</span></a>
            </li>
            <li <?=($_SERVER['PHP_SELF']=='/list-avto.php')?'class="active"':'';?>>
                <a href="list-avto.php"><i class="fa fa-users"></i><span>Автомобили</span></a>
            </li>
            <li class="header">Управление путевыми листами</li>
            <li <?=($_SERVER['PHP_SELF']=='/list-pyt_list.php')?'class="active"':'';?>>
                <a href="list-pyt_list.php"><i class="fa fa-users"></i><span>Путевой лист</span></a>
            </li>
        </ul>
    </section>
</aside>